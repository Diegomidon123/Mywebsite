<h2 style="text-align:center;">Welcome to My Website</h2>
<p style="text-align:center;">This site shares interesting information, current news, and more.</p>

<div class="home-gallery">
    <img src="https://picsum.photos/seed/a1/400/250" alt="Image 1">
    <img src="https://picsum.photos/seed/a2/400/250" alt="Image 2">
    <img src="https://picsum.photos/seed/a3/400/250" alt="Image 3">
</div>


