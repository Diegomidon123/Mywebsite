<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include 'db.php';

if (!isset($_SESSION['username'])) {
    echo "<p>You must be logged in to edit news.</p>";
    exit();
}

if (!isset($_GET['id'])) {
    echo "<p>News ID is missing.</p>";
    exit();
}

$id = $_GET['id'];
$user = $_SESSION['username'];

// Search the new and verify that it belogns to the user
$stmt = $conn->prepare("SELECT title, content, image FROM news WHERE id = ? AND user = ?");
$stmt->bind_param("is", $id, $user);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    echo "<p>You can only edit your own news.</p>";
    exit();
}

$row = $result->fetch_assoc();
?>

<h2>Edit News Post</h2>

<form action="scripts/process_edit_news.php" method="post" enctype="multipart/form-data" class="contact-form">
    <input type="hidden" name="id" value="<?php echo $id; ?>">
    
    <input type="text" name="title" value="<?php echo htmlspecialchars($row['title']); ?>" required>
    
    <textarea name="content" rows="6" required><?php echo htmlspecialchars($row['content']); ?></textarea>

    <?php if (!empty($row['image'])): ?>
        <p>Current Image:</p>
        <img src="uploads/<?php echo htmlspecialchars($row['image']); ?>" style="width:300px; max-height:200px; object-fit:cover; border-radius:8px;">
    <?php endif; ?>

    <p>Replace Image (optional):</p>
    <input type="file" name="image" accept="image/*">

    <button type="submit">Save Changes</button>
</form>

