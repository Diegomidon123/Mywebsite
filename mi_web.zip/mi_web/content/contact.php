<h2>Contact Us</h2>

<!-- Map -->
<div class="map-container">
    <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d195126.72180899073!2d-0.4312484!3d39.5072284!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd604f1f79576df1%3A0x40f5d67c42f911a9!2sValencia!5e0!3m2!1sen!2ses!4v1615120123456!5m2!1sen!2ses"
        width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy">
    </iframe>
</div>

<!-- Contact Form -->
<form action="scripts/process_contact.php" method="post" class="contact-form">
    <input type="text" name="name" placeholder="Your name" required>
    <input type="email" name="email" placeholder="Your email" required>
    <textarea name="message" rows="5" placeholder="Your message..." required></textarea>
    <button type="submit">Send Message</button>
</form>


