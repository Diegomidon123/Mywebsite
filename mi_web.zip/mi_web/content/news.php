<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'db.php';

echo "<h2>Latest News</h2>";

// Mostrar botón de añadir noticia solo si el usuario está logueado
if (isset($_SESSION['username'])) {
    echo '<p><a href="index.php?menu=add_news" class="button">➕ Add News</a></p>';
}

$user_logged_in = isset($_SESSION['username']) ? $_SESSION['username'] : null;

// Obtain all new ordered by date
$sql = "SELECT id, user, title, content, image, created_at FROM news ORDER BY created_at DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo '<div class="news-container">';
    while ($row = $result->fetch_assoc()) {
        echo '<div class="news-card">';
        echo '<h3>' . htmlspecialchars($row['title']) . '</h3>';
        echo '<p><strong>By:</strong> ' . htmlspecialchars($row['user']) . '</p>';
        
        // Show image if exists
        if (!empty($row['image'])) {
            echo '<img src="uploads/' . htmlspecialchars($row['image']) . '" style="width:100%; max-height:200px; object-fit:cover; border-radius:8px; margin-top:10px;">';
        }

        // Show recort content
        echo '<p style="margin-top:10px;">' . nl2br(htmlspecialchars(substr($row['content'], 0, 100))) . '...</p>';
        echo '<p><small>' . $row['created_at'] . '</small></p>';
        
        // Buttons of edit and delete only if the user is the autor
        if ($user_logged_in && $row['user'] === $user_logged_in) {
            echo '<a href="index.php?menu=edit_news&id=' . $row['id'] . '" class="button">Edit</a> ';
            echo '<a href="scripts/delete_news.php?id=' . $row['id'] . '" class="button danger" onclick="return confirm(\'Are you sure you want to delete this post?\')">Delete</a>';
        }

        echo '</div>';
    }
    echo '</div>';
} else {
    echo "<p>No news posts available.</p>";
}

$conn->close();
?>
