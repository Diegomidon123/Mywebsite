<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['username'])) {
    echo "<p>You must be logged in to add a news post.</p>";
    echo '<p><a href="index.php?menu=login">Sign In</a></p>';
    exit();
}
?>

<h2>Create News Post</h2>

<form action="scripts/process_add_news.php" method="post" enctype="multipart/form-data" class="contact-form">
    <input type="text" name="title" placeholder="News title" required>
    <textarea name="content" placeholder="Write your news content here..." rows="6" required></textarea>
    <input type="file" name="image" accept="image/*">
    <button type="submit">Publish</button>
</form>

