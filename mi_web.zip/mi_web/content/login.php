<h2>Sign In</h2>

<form action="scripts/process_login.php" method="post" class="contact-form">
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Sign In</button>
</form>

