<h2>User Registration</h2>

<form action="scripts/process_register.php" method="post" class="contact-form">
    <input type="text" name="first_name" placeholder="First Name" required>
    <input type="text" name="last_name" placeholder="Last Name" required>
    <input type="email" name="email" placeholder="Email" required>
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password (min. 5 characters)" required>
    <input type="text" name="country" placeholder="Country" required>
    <button type="submit">Register</button>
</form>


