<?php
session_start();
$page = isset($_GET['menu']) ? $_GET['menu'] : 'home';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Personal Website</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <div class="container">
        <?php include 'menu.php'; ?>
        <div class="content">
            <?php
            $file = "content/$page.php";
            if (file_exists($file)) {
                include $file;
            } else {
                echo "<p>Content not found.</p>";
            }
            ?>
        </div>
    </div>
    <?php include 'footer.php'; ?>
</body>
</html>
