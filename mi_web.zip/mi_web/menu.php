<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<div class="menu">
    <a href="index.php?menu=home">Home</a>
    <a href="index.php?menu=news">News</a>
    <a href="index.php?menu=contact">Contact</a>
    <a href="index.php?menu=register">Register</a>

    <?php if (isset($_SESSION['username'])): ?>
        <span style="display:block; margin-top:10px; color:white;">
            Welcome, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>
        </span>
        <a href="logout.php" style="background-color:#aa0000;">Log Out</a>
    <?php else: ?>
        <a href="index.php?menu=login">Sign In</a>
    <?php endif; ?>
</div>







