<?php
session_start();
include '../db.php';

if (!isset($_SESSION['username'])) {
    echo "<p>You must be logged in.</p>";
    exit();
}

if (!isset($_GET['id'])) {
    echo "<p>Missing news ID.</p>";
    exit();
}

$id = $_GET['id'];
$user = $_SESSION['username'];

// Ensure the user owns the news post
$stmt = $conn->prepare("DELETE FROM news WHERE id = ? AND user = ?");
$stmt->bind_param("is", $id, $user);

if ($stmt->execute()) {
    echo "<p>News deleted successfully.</p>";
    echo '<p><a href="../index.php?menu=news">← Back to News</a></p>';
} else {
    echo "<p>Error deleting news.</p>";
}
?>
