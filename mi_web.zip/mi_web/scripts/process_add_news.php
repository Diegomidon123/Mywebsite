<?php
session_start();
include '../db.php';

if (!isset($_SESSION['username'])) {
    echo "<p>You must be logged in to post news.</p>";
    exit();
}

$user = $_SESSION['username'];
$title = $_POST['title'];
$content = $_POST['content'];

// Upload image
$imageName = null;

if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
    $targetDir = "../uploads/";
    if (!file_exists($targetDir)) {
        mkdir($targetDir);
    }
    $imageName = basename($_FILES["image"]["name"]);
    $targetFile = $targetDir . $imageName;
    move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile);
}

// Save in DB
$stmt = $conn->prepare("INSERT INTO news (user, title, content, image) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $user, $title, $content, $imageName);

if ($stmt->execute()) {
    echo "<p>News post created successfully.</p>";
    echo '<p><a href="../index.php?menu=news">Go to News</a></p>';
} else {
    echo "<p>Error creating news post.</p>";
}
$conn->close();
?>

