<?php
session_start();
include '../db.php';

if (!isset($_SESSION['username'])) {
    echo "<p>You must be logged in.</p>";
    exit();
}

$id = $_POST['id'];
$title = $_POST['title'];
$content = $_POST['content'];
$user = $_SESSION['username'];

// Check if the image is uploaded
$imageName = null;
if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
    $targetDir = "../uploads/";
    if (!file_exists($targetDir)) {
        mkdir($targetDir);
    }
    $imageName = basename($_FILES["image"]["name"]);
    $targetFile = $targetDir . $imageName;
    move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile);

    // Upload also the image
    $stmt = $conn->prepare("UPDATE news SET title = ?, content = ?, image = ? WHERE id = ? AND user = ?");
    $stmt->bind_param("sssis", $title, $content, $imageName, $id, $user);
} else {
    // Only upload text
    $stmt = $conn->prepare("UPDATE news SET title = ?, content = ? WHERE id = ? AND user = ?");
    $stmt->bind_param("ssis", $title, $content, $id, $user);
}

if ($stmt->execute()) {
    header("Location: ../index.php?menu=news");
    exit();
} else {
    echo "<p>Error updating news.</p>";
}
?>

