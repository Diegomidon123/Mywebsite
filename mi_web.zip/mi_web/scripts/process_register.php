<?php
include '../db.php';

$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$email = $_POST['email'];
$username = $_POST['username'];
$password = $_POST['password'];
$country = $_POST['country'];

// Validate password length
if (strlen($password) < 5) {
    echo "<p>Password must be at least 5 characters long. <a href='../index.php?menu=register'>Back</a></p>";
    exit();
}

// Check if username or password already exists
$check = $conn->prepare("SELECT * FROM users WHERE username = ? OR password = ?");
$hashed_password_check = password_hash($password, PASSWORD_DEFAULT);
$check->bind_param("ss", $username, $hashed_password_check);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    echo "<p>That username or password is already taken. <a href='../index.php?menu=register'>Back</a></p>";
    exit();
}

// Hash password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Insert user
$stmt = $conn->prepare("INSERT INTO users (first_name, last_name, email, username, password, country) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssss", $first_name, $last_name, $email, $username, $hashed_password, $country);

if ($stmt->execute()) {
    echo "<p>User registered successfully. <a href='../index.php?menu=login'>Sign in</a></p>";
} else {
    echo "<p>Error registering user.</p>";
}

$conn->close();
?>
