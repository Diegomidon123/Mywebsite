<?php
include '../db.php';

$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

// Escape strings
$name = $conn->real_escape_string($name);
$email = $conn->real_escape_string($email);
$message = $conn->real_escape_string($message);

// Insert message
$sql = "INSERT INTO messages (name, email, message) VALUES ('$name', '$email', '$message')";

if ($conn->query($sql) === TRUE) {
    echo "<p>Message sent successfully. Thank you for contacting us!</p>";
    echo '<p><a href="../index.php?menu=contact">← Back</a></p>';
} else {
    echo "<p>Error sending message.</p>";
}

$conn->close();
?>

