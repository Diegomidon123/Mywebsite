<?php
session_start();
include '../db.php';

$username = $_POST['username'];
$password = $_POST['password'];

// Verify if the user exists
$stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 1) {
    $stmt->bind_result($hashed_password);
    $stmt->fetch();

    if (password_verify($password, $hashed_password)) {
        // Guardar el usuario en la sesión
        $_SESSION['username'] = $username;

        // Go to the News page
        header("Location: ../index.php?menu=news");
        exit();
    } else {
        echo "<p>Incorrect password. <a href='../index.php?menu=login'>Back</a></p>";
    }
} else {
    echo "<p>User not found. <a href='../index.php?menu=login'>Back</a></p>";
}

$stmt->close();
$conn->close();
?>
