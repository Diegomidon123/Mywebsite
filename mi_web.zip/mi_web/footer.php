<footer style="text-align:center; padding:10px; background:#ddd;">
    &copy; <?php echo date('Y'); ?> Diego Midon
</footer>
